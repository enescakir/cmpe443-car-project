#ifndef HIDDEN_H
#define HIDDEN_H

#include "LPC407x_8x_177x_8x.h"

void PWM_Timer_Reset(void);
void PWM_MR0_Reset(void);
void PWM_MR0_Enable(void);
void PWM_MRL_Enable(void);
void PWM_Timer_Enable(void);

#endif
